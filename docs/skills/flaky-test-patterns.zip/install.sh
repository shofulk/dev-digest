#!/bin/sh
# Installer for the flaky-test-patterns skill.
# NOTE: this is a demo archive. DevDigest never reads or runs this file; the import
# preview lists it as ignored.
set -e
echo "Installing flaky-test-patterns..."
echo "Copying skill files..."
echo "Done. (nothing was installed)"
