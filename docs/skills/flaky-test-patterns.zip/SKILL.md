---
name: flaky-test-patterns
description: Apply when a PR adds or changes tests, to flag patterns that make them pass or fail nondeterministically.
---

# Flaky test patterns

A flaky test passes and fails on the same code. It trains the team to ignore red CI, so it
is worse than no test. Read every test the diff adds or changes and look for the patterns
below.

## Patterns to flag

- **Sleeps and timeouts.** `setTimeout`, `sleep(n)` or a fixed `waitFor` delay used to wait
  for something to happen. Fix: wait on the condition itself (poll with a bounded retry, await
  the promise or event), or use fake timers.
- **Shared mutable state.** Module-level variables, a shared database row or a singleton that
  one test writes and another reads, with no reset in `beforeEach` / `afterEach`. Fix: create
  fresh state per test, or roll back after each one.
- **Ordering dependence.** A test that only passes because an earlier test ran first, or that
  relies on `Object.keys` order, unsorted query results or `Promise.all` completion order.
  Fix: make each test self-contained and sort before comparing.
- **Unmocked clock or randomness.** `Date.now()`, `new Date()`, `Math.random()` or a generated
  id that reaches an assertion. Fix: inject a clock, use fake timers with a fixed system time,
  seed the generator or assert on shape rather than value.
- **Real network or filesystem.** A call to a live host, a fixed port, or a shared temp path.
  Fix: stub the adapter, bind port 0, use a per-test temp directory.
- **Unawaited async work.** A promise that is not awaited or returned, an `expect` inside a
  callback the test does not wait for, `forEach(async ...)`. Fix: `await` it, use
  `await expect(...).resolves` and replace `forEach` with `for...of`.

## Severity

- **WARNING** for any pattern above in a test the diff adds or changes.
- **CRITICAL** only when the flakiness is certain from the diff (an unawaited assertion that
  can never fail, or a hard dependency on another test's leftover state).
- **SUGGESTION** for a pattern that is present but unlikely to bite (a sleep of a few
  milliseconds around a synchronous mock).

## How to report

Cite the exact line, name the pattern, say what makes the outcome vary (which value or timing),
and give the concrete fix in one or two sentences. Report one finding per distinct cause.
